import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split

df = pd.read_csv(r"C:\\IBMProject\\Assignments\\IBMAssgt2\\Churn_Modelling.csv")

#Descriptive Statistics
print()
print("Descriptive Statistics")
print()
print(df.describe())

#Handling Missing Values
print()
print("Count of null values in dataframe fields : ")
print()
print(df.isnull().sum()) #since there are no null values in any field, handling them not required

#Find and replace outliers
new_df = pd.read_csv(r"C:\\IBMProject\\Assignments\\IBMAssgt2\\Churn_Modelling.csv")
median = new_df['Balance'].median()
std = new_df['Balance'].std()
outliers = (new_df['Balance']-median).abs()>std
new_df[outliers]=np.nan
new_df['Balance'].fillna(median, inplace=True)
print()
print("Dataset after replacing outliers with median : ")
print()
print(new_df[['Balance']])

#Find categorical columns
print()
print("Categorical Columns : ")
print()
print(df.select_dtypes(exclude='number'))

#Perform encoding on 'Gender' column
new_df = pd.read_csv(r"C:\\IBMProject\\Assignments\\IBMAssgt2\\Churn_Modelling.csv")
encoder = OneHotEncoder(handle_unknown='ignore')
encoder_df = pd.DataFrame(encoder.fit_transform(new_df[['Gender']]).toarray())
final_df = new_df.join(encoder_df)
print()
print("Dataset after encoding Gender values : ")
print()
print(final_df[['Surname', 'Gender', 0, 1]].head(10))

#Split data into dependent and independent variables
X=df.iloc[:,[True, True, True, True, True, True, True, True, True, True, True, True, False, True]]
print()
print("Independent feature values : ")
print()
print(X.head(10).values)
Y=df.iloc[:,-2]
print()
print("Dependent feature (Estimated Salary) values : ")
print()
print(Y.head(10).values)

#Scale the independent variables (Min-Max Normalization)
df_norm=(Y-Y.min())/(Y.max()-Y.min())
print()
print("Dataset after min-max normalization : ")
print()
print(df_norm.head(10))

#Split the data into training and testing datasets
X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2)
print()
print("Shape of original dataset : ", df.shape)
print("Shape of training set input : ", X_train.shape)
print("Shape of training set output : ", Y_train.shape)
print("Shape of testing set input : ", X_test.shape)
print("Shape of testing set output : ", Y_test.shape)
print()