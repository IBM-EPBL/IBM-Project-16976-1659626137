import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn

df = pd.read_csv(r"C:\\IBMProject\\Assignments\\IBMAssgt2\\Churn_Modelling.csv")
print()
print("CSV file read succesfully")
print()
print(df.head())

#Univariate Analysis
df_france = df.loc[df['Geography']=='France']
df_spain = df.loc[df['Geography']=='Spain']
df_germany = df.loc[df['Geography']=='Germany']

plt.plot(df_france['CreditScore'])
plt.plot(df_spain['CreditScore'])
plt.plot(df_germany['CreditScore'])
plt.show()

plt.plot(df_france['CreditScore'],np.zeros_like(df_france['CreditScore']),'o')
plt.plot(df_spain['CreditScore'],np.zeros_like(df_spain['CreditScore']),'o')
plt.plot(df_germany['CreditScore'],np.zeros_like(df_germany['CreditScore']),'o')
plt.xlabel('CreditScore')
plt.show()

#Bivariate Analysis
sns.FacetGrid(df,hue='Geography').map(plt.scatter,"Tenure","CreditScore").add_legend()
plt.show()

#Multivariate Analysis
sns.pairplot(df,vars=['CreditScore', 'Age', 'Tenure', 'NumOfProducts'],hue="HasCrCard",height=5)
plt.show()